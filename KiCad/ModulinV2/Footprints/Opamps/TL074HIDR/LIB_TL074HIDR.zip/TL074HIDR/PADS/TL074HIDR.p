*PADS-LIBRARY-PART-TYPES-V9*

TL074HIDR SOIC127P600X175-14N I ANA 9 1 0 0 0
TIMESTAMP 2025.07.08.13.02.24
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TL074HIDR
"Mouser Part Number" 595-TL074HIDR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TL074HIDR?qs=81r%252BiQLm7BSo1sbhfEy0IA%3D%3D
"Arrow Part Number" TL074HIDR
"Arrow Price/Stock" null?utm_currency=USD&region=nac
"Description" Quad, 40-V, 5-MHz, 4-mV offset voltage, 20-V/s, In to V+ op amp with -40C to 125C operation
"Datasheet Link" https://www.ti.com/lit/ds/symlink/tl074h.pdf?ts=1631523791573&ref_url=https%253A%252F%252Fwww.ti.com%252Fproduct%252FTL074H
"Geometry.Height" 1.75mm
GATE 1 14 0
TL074HIDR
1 0 U 1OUT
2 0 U 1IN-
3 0 U 1IN+
4 0 U VCC+
5 0 U 2IN+
6 0 U 2IN-
7 0 U 2OUT
14 0 U 4OUT
13 0 U 4IN-
12 0 U 4IN+
11 0 U VCC-
10 0 U 3IN+
9 0 U 3IN-
8 0 U 3OUT

*END*
*REMARK* SamacSys ECAD Model
14921006/1663443/2.50/14/3/Integrated Circuit
