*PADS-LIBRARY-PART-TYPES-V9*

TL072HIDR SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2025.07.08.13.02.52
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TL072HIDR
"Mouser Part Number" 595-TL072HIDR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TL072HIDR?qs=aP1CjGhiNiHyZHNBkxIRdA%3D%3D
"Arrow Part Number" TL072HIDR
"Arrow Price/Stock" https://www.arrow.com/en/products/tl072hidr/texas-instruments?utm_currency=USD&region=nac
"Description" Dual-channel low input bias current standard op amp
"Datasheet Link" https://www.ti.com/lit/ds/symlink/tl072h.pdf?ts=1631525097016&ref_url=https%253A%252F%252Fwww.ti.com%252Fproduct%252FTL072H
"Geometry.Height" 1.75mm
GATE 1 8 0
TL072HIDR
1 0 U 1OUT
2 0 U 1IN-
3 0 U 1IN+
4 0 U VCC-
8 0 U VCC+
7 0 U 2OUT
6 0 U 2IN-
5 0 U 2IN+

*END*
*REMARK* SamacSys ECAD Model
14921004/1663443/2.50/8/3/Integrated Circuit
